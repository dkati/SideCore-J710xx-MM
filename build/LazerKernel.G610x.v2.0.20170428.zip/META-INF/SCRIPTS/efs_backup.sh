#!/system/bin/sh

chmod 640 /sys/fs/selinux/enforce
chmod 440 /sys/fs/selinux/policy

